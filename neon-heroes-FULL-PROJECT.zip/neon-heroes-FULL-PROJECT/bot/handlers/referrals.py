# referrals handler placeholder for Telegram bot integration.
