# start handler placeholder for Telegram bot integration.
