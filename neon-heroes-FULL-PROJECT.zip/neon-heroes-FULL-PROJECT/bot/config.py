import os
TOKEN=os.getenv('TELEGRAM_BOT_TOKEN','')
WEBAPP_URL=os.getenv('WEBAPP_URL','https://YOUR-DOMAIN/')
