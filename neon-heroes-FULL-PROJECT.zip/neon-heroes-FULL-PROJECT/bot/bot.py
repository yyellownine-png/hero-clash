"""Minimal Telegram launcher. Install aiogram separately for production bot deployment."""
# The Mini App itself is independent from this launcher. Set TELEGRAM_BOT_TOKEN and WEBAPP_URL.
