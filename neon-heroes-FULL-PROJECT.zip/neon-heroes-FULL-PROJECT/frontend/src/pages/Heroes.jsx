export default function Heroes(){return null}
