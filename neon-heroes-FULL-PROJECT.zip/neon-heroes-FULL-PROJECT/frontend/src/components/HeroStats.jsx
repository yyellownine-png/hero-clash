export default function HeroStats(props){return null}
