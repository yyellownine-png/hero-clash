export default function EnergyBar(props){return null}
