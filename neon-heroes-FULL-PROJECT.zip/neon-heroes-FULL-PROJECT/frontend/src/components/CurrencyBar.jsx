export default function CurrencyBar(props){return null}
