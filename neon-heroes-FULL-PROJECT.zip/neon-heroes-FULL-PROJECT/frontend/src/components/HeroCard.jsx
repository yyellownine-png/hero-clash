export default function HeroCard(props){return null}
