// Runtime UI is served by frontend/app.js for zero-build deployment. This component documents the app entry point.
export default function App(){return null}