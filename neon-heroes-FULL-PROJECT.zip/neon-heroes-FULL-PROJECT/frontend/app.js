const $=s=>document.querySelector(s);let pid=1,lang='ru',state={heroes:[],world:[],profile:null};
const ru={home:'Главная',world:'Мир',heroes:'Герои',chests:'Сундуки',rank:'Рейтинг',play:'ИГРАТЬ',open:'ОТКРЫТЬ',power:'СИЛА',energy:'ЭНЕРГИЯ',coins:'МОНЕТЫ',gems:'GEMS'};const en={home:'Home',world:'World',heroes:'Heroes',chests:'Chests',rank:'Rank',play:'PLAY',open:'OPEN',power:'POWER',energy:'ENERGY',coins:'COINS',gems:'GEMS'};
const t=k=>(lang==='ru'?ru:en)[k]||k;
async function api(u,o){let r=await fetch(u,o);let x=await r.json();if(!r.ok)throw Error(x.detail||'error');return x}
async function load(){state.profile=await api('/api/profile/'+pid);state.heroes=await api('/api/heroes/player/'+pid);state.world=await api('/api/world');render('home')}
function heroCard(h){return `<div class="hero ${h.rarity.toLowerCase()}" onclick="heroInfo(${h.id})"><img src="${h.art}"><div class="heroShade"></div><div class="heroInfo"><b>${h.name}</b><small>${h.rarity} · ${h.class_name}</small><span>⚔ ${h.atk} · ❤ ${h.hp}</span></div></div>`}
function shell(content,active){$('#app').innerHTML=`<main><header><div class="brand">NEON<span>HEROES</span></div><div class="curr">💎 ${state.profile.gems} &nbsp; 🪙 ${state.profile.coins}</div></header>${content}<nav>${[['home','⌂'],['world','◈'],['heroes','♜'],['chests','◇'],['rank','♛']].map(x=>`<button class="${active===x[0]?'on':''}" onclick="render('${x[0]}')">${x[1]}<small>${t(x[0])}</small></button>`).join('')}</nav></main>`}
function render(page){if(page==='home')home();if(page==='heroes')heroes();if(page==='chests')chests();if(page==='world')world();if(page==='rank')rank()}
function home(){let p=state.profile;let power=state.heroes.reduce((a,h)=>a+h.atk+h.defense,0);shell(`<section class="heroHome"><div class="glow"></div><div><small>LEVEL ${p.level}</small><h1>NEON<br>OUTPOST</h1><p>Collect. Build. Fight. Evolve.</p></div><button class="play" onclick="render('world')">${t('play')} →</button></section><section class="stats"><div>⚡<b>${p.energy}/${p.max_energy}</b><small>${t('energy')}</small></div><div>⚔<b>${power}</b><small>${t('power')}</small></div><div>★<b>${state.heroes.length}</b><small>${t('heroes')}</small></div></section><h2>YOUR SQUAD</h2><div class="grid">${state.heroes.slice(0,4).map(heroCard).join('')}</div>`, 'home')}
function heroes(){shell(`<section class="page"><h1>${t('heroes')}</h1><p class="muted">${state.heroes.length} / 40 collected</p><div class="grid">${state.heroes.map(heroCard).join('')}</div></section>`,'heroes')}
function chests(){let cs=[['basic','Basic',3],['rare','Rare',7],['epic','Epic',15],['legendary','Legendary',30]];shell(`<section class="page"><h1>${t('chests')}</h1><p class="muted">Open a case and add a new hero to your squad.</p><div class="chests">${cs.map(c=>`<div class="chest ${c[0]}"><div class="chestArt">▣</div><h2>${c[1]}</h2><span>💎 ${c[2]}</span><button onclick="openChest('${c[0]}')">${t('open')}</button></div>`).join('')}</div></section>`,'chests')}
function world(){let ds=[...new Set(state.world.map(x=>x.district))];shell(`<section class="page"><h1>${t('world')}</h1>${ds.map(d=>`<div class="district"><div><b>DISTRICT ${d}</b><small>Sector ${String(d).padStart(2,'0')}</small></div><div class="missions">${state.world.filter(x=>x.district===d).map(m=>`<button onclick="battle(${m.id})"><b>${m.number}</b><small>⚔ ${m.enemy_power}</small></button>`).join('')}</div></div>`).join('')}</section>`,'world')}
async function rank(){let r=await api('/api/rankings');shell(`<section class="page"><h1>${t('rank')}</h1>${r.map((x,i)=>`<div class="rank"><b>#${i+1}</b><span>${x.name}</span><small>LV ${x.level}</small></div>`).join('')}</section>`,'rank')}
async function openChest(c){try{let h=await api('/api/chests/open?player_id='+pid,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chest:c})});alert(`NEW HERO: ${h.name} · ${h.rarity}`);await load();render('heroes')}catch(e){alert(e.message)}}
async function battle(id){try{let r=await api('/api/battles/run?player_id='+pid,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mission_id:id})});alert(r.win?`VICTORY! +${r.coins} coins +${r.gems} gems`:'DEFEAT');await load()}catch(e){alert(e.message)}}
function heroInfo(id){let h=state.heroes.find(x=>x.id===id);alert(`${h.name}
${h.rarity} · ${h.class_name}
HP ${h.hp}
ATK ${h.atk}
DEF ${h.defense}
${h.ability}
${h.passive}`)}
load().catch(e=>alert(e.message));
