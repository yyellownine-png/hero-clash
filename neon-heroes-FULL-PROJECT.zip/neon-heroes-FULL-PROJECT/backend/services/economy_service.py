def can_spend(player,field,amount): return player[field]>=amount
def add_currency(c,pid,field,amount): c.execute(f'UPDATE players SET {field}={field}+? WHERE id=?',(amount,pid))
def spend_currency(c,pid,field,amount):
    cur=c.execute(f'UPDATE players SET {field}={field}-? WHERE id=? AND {field}>=?',(amount,pid,amount))
    return cur.rowcount==1
