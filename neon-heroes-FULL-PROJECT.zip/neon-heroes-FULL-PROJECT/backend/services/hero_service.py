import json,random
from pathlib import Path
HEROES=json.loads(Path('backend/data/heroes.json').read_text())
def seed_heroes(c):
    for h in HEROES:
        c.execute('INSERT OR IGNORE INTO heroes(code,name,rarity,class_name,hp,atk,defense,ability,passive,art) VALUES(?,?,?,?,?,?,?,?,?,?)',tuple(h.values()))
def weighted_rarity(weights):
    total=sum(weights.values()); r=random.uniform(0,total)
    for k,v in weights.items():
        r-=v
        if r<=0:return k
    return next(iter(weights))
def give_random_hero(c,pid,rarity):
    rows=c.execute('SELECT * FROM heroes WHERE rarity=?',(rarity,)).fetchall()
    h=random.choice(rows); c.execute('INSERT OR IGNORE INTO player_heroes(player_id,hero_id) VALUES(?,?)',(pid,h['id'])); return dict(h)
