def add_xp(c,pid,xp):
    row=c.execute('SELECT level,xp FROM players WHERE id=?',(pid,)).fetchone(); total=row['xp']+xp; level=row['level']
    while total>=level*500: total-=level*500; level+=1
    c.execute('UPDATE players SET xp=?,level=? WHERE id=?',(total,level,pid))
