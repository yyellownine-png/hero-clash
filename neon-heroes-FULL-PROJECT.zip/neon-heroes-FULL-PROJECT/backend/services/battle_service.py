def run_battle(c,pid,mission_id):
    m=c.execute('SELECT * FROM missions WHERE id=?',(mission_id,)).fetchone()
    if not m: raise ValueError('mission_not_found')
    p=c.execute('SELECT * FROM players WHERE id=?',(pid,)).fetchone()
    if p['energy']<m['energy_cost']: raise ValueError('not_enough_energy')
    heroes=c.execute('SELECT h.* FROM heroes h JOIN player_heroes ph ON ph.hero_id=h.id WHERE ph.player_id=? AND ph.equipped=1',(pid,)).fetchall()
    if not heroes: heroes=c.execute('SELECT h.* FROM heroes h JOIN player_heroes ph ON ph.hero_id=h.id WHERE ph.player_id=? LIMIT 4',(pid,)).fetchall()
    power=sum(h['atk']+h['defense']+h['hp']//5 for h in heroes)
    import random
    win=power>=m['enemy_power']*0.7 or random.random()<min(.35,power/(m['enemy_power']*8))
    c.execute('UPDATE players SET energy=energy-? WHERE id=?',(m['energy_cost'],pid))
    if win:
        c.execute('UPDATE players SET coins=coins+?, gems=gems+?, xp=xp+? WHERE id=?',(m['reward_coins'],m['reward_gems'],100,pid))
    c.execute('INSERT INTO battle_log(player_id,mission_id,result,damage,reward_coins,reward_gems) VALUES(?,?,?,?,?,?)',(pid,mission_id,'win' if win else 'lose',power,m['reward_coins'] if win else 0,m['reward_gems'] if win else 0))
    return {'win':win,'power':power,'coins':m['reward_coins'] if win else 0,'gems':m['reward_gems'] if win else 0}
