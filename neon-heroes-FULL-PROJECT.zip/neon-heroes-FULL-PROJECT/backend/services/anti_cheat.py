# Central place for rate limits, suspicious event logging and future Redis-backed protections.
def clamp_int(value,minimum=0,maximum=10**9): return max(minimum,min(maximum,int(value)))
