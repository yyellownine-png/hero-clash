import hashlib,hmac,urllib.parse
from backend.config import BOT_TOKEN

def validate_init_data(init_data:str|None):
    if not init_data: return None
    if not BOT_TOKEN: return None
    q=dict(urllib.parse.parse_qsl(init_data,keep_blank_values=True)); received=q.pop('hash',None)
    if not received: return None
    data='\n'.join(f'{k}={q[k]}' for k in sorted(q))
    secret=hmac.new(b'WebAppData',BOT_TOKEN.encode(),hashlib.sha256).digest()
    check=hmac.new(secret,data.encode(),hashlib.sha256).hexdigest()
    return q.get('user') if hmac.compare_digest(check,received) else None
