import json
from pathlib import Path
from .hero_service import weighted_rarity,give_random_hero
CHESTS={x['code']:x for x in json.loads(Path('backend/data/chests.json').read_text())}
def open_chest(c,pid,code):
    chest=CHESTS.get(code)
    if not chest:return None
    row=c.execute('SELECT gems FROM players WHERE id=?',(pid,)).fetchone()
    if not row or row['gems']<chest['cost']: raise ValueError('not_enough_gems')
    c.execute('UPDATE players SET gems=gems-? WHERE id=?',(chest['cost'],pid))
    rarity=weighted_rarity(chest['weights']); return give_random_hero(c,pid,rarity)
